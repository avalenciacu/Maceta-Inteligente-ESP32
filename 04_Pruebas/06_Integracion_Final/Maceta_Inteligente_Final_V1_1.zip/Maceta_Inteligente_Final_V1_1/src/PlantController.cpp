#include "PlantController.h"
using namespace SystemConfig;

namespace {
constexpr Mood idleMoods[]={
    Mood::NORMAL,Mood::HAPPY,Mood::ADMIRATION,Mood::CURIOUS,Mood::SURPRISED,
    Mood::SKEPTICAL,Mood::WINK,Mood::LAUGH,Mood::THINKING,Mood::SINGING,
    Mood::WHISTLING,Mood::BORED,Mood::MISCHIEVOUS,Mood::CONFUSED,
    Mood::SHY,Mood::EXCITED,Mood::RELAXED,Mood::TONGUE,Mood::DISSEMBLING,
    Mood::READING,Mood::SUNGLASSES,Mood::MICROPHONE,Mood::MAGNIFIER,
    Mood::GAMING,Mood::BUBBLES,Mood::FLOWER,Mood::BALLOON,Mood::MAGIC,
    Mood::PAINTING,Mood::CAMERA,Mood::CELEBRATING,Mood::EXERCISE,Mood::ICE_CREAM
};

}
const char* modeName(PlantMode m){
    switch(m){
    case PlantMode::Idle:return "ACTIVA";
    case PlantMode::Yawn:return "BOSTEZO";
    case PlantMode::Sleeping:return "DORMIDA";
    case PlantMode::Waking:return "DESPERTANDO";
    case PlantMode::TouchAlert:return "ALERTA_TACTIL";
    case PlantMode::Petting:return "CARICIA";
    case PlantMode::Annoyed:return "INCOMODA";
    case PlantMode::Stressed:return "ESTRES";
    case PlantMode::Recovery:return "RECUPERACION";
    case PlantMode::Heat:return "CALOR";
    case PlantMode::Dry:return "FALTA_AGUA";
    case PlantMode::Overwater:return "EXCESO_AGUA";
    case PlantMode::Drinking:return "BEBIENDO";
    case PlantMode::Satisfied:return "SATISFECHA";
    }
    return "?";
}
void PlantController::begin(uint32_t now){
    inactivityAt=entered=now;
    initialized=false;nextIdle=now;
    previousTouch=previousNeed=knownSoil=false;
    wake=alertTouch=recover=waterQueued=false;
    waterStage=0;bagSize=bagPos=recentPos=0;
    for(auto& m:recent)m=Mood::COUNT;
}
bool PlantController::recentlyShown(Mood m)const{
    for(auto x:recent)if(x==m)return true;
    return false;
}
void PlantController::refillBag(){
    bagSize=sizeof(idleMoods)/sizeof(idleMoods[0]);
    for(uint8_t i=0;i<bagSize;++i)bag[i]=idleMoods[i];
    for(int i=bagSize-1;i>0;--i){
        int j=random(i+1);Mood t=bag[i];bag[i]=bag[j];bag[j]=t;
    }
    bagPos=0;
}
Mood PlantController::chooseIdle(){
    if(bagPos>=bagSize)refillBag();
    for(uint8_t i=bagPos;i<bagSize;++i){
        if(!recentlyShown(bag[i])&&bag[i]!=currentMood){
            Mood t=bag[bagPos];bag[bagPos]=bag[i];bag[i]=t;break;
        }
    }
    Mood m=bag[bagPos++];
    // At a bag boundary avoid repeating the current or recently seen face.
    if(recentlyShown(m)||m==currentMood){
        if(bagPos>=bagSize)refillBag();
        for(uint8_t i=bagPos;i<bagSize;++i){
            if(!recentlyShown(bag[i])&&bag[i]!=currentMood){
                Mood t=bag[bagPos];bag[bagPos]=bag[i];bag[i]=t;
                m=bag[bagPos++];break;
            }
        }
    }
    recent[recentPos++%4]=m;
    return m;
}
FaceDecision PlantController::show(uint32_t now,PlantMode mode,Mood mood,uint32_t ms,bool force){
    bool changed=!initialized||force||mode!=currentMode||mood!=currentMood;
    if(changed){currentMode=mode;currentMood=mood;duration=ms;entered=now;initialized=true;}
    return {currentMood,duration,currentMode,changed};
}
FaceDecision PlantController::update(uint32_t now,const PlantInputs& in){
    const bool need=in.hot||(in.soilReady&&needsAlert(in.soil));
    const bool pressed=in.touching&&!previousTouch;
    const bool released=!in.touching&&previousTouch;
    previousTouch=in.touching;

    // Water event requires a confirmed transition from a dry state to Adequate.
    // Neither start-up nor a transition to Excess can trigger drinking.
    if(in.soilReady){
        if(knownSoil&&isDry(previousSoil)&&in.soil==SoilState::Adequate){
            waterQueued=true;waterAt=now;
        }
        previousSoil=in.soil;knownSoil=true;
        if(in.soil!=SoilState::Adequate){waterQueued=false;waterStage=0;}
    }
    if(waterQueued&&now-waterAt>WATER_MAX_WAIT)waterQueued=false;

    if(previousNeed&&!need)inactivityAt=now;
    previousNeed=need;
    if(in.touching||released)inactivityAt=now;

    if(pressed){
        recover=false;
        // A new interaction preempts a running watering animation.
        waterStage=0;
        wake=currentMode==PlantMode::Sleeping||currentMode==PlantMode::Yawn;
        if(wake){wakeAt=now;alertTouch=false;}
        else{alertTouch=true;touchAlertAt=now;}
    }
    if(released){
        recover=true;recoveryAt=now;
    }

    // Waking is an intentional one-shot sequence, even for a short tap.
    if(wake){
        if(now-wakeAt<WAKE_MS)return show(now,PlantMode::Waking,Mood::WAKE_UP,WAKE_MS);
        wake=false;alertTouch=true;touchAlertAt=now;
    }
    if(alertTouch){
        if(now-touchAlertAt<TOUCH_ALERT_MS)
            return show(now,PlantMode::TouchAlert,Mood::TOUCH_ALERT,TOUCH_ALERT_MS);
        alertTouch=false;
    }

    // Actual confirmed contact duration, including the wake animation.
    if(in.touching){
        uint32_t held=in.touchDuration;
        if(held<PET_MS)return show(now,PlantMode::Petting,Mood::PETTED);
        if(held<ANNOYED_MS)return show(now,PlantMode::Annoyed,Mood::ANNOYED);
        // Stress persists until release; alternate anger after a sustained interval.
        Mood m=((held-ANNOYED_MS)/STRESS_ALTERNATE_MS)%2?Mood::ANGRY:Mood::STRESSED;
        return show(now,PlantMode::Stressed,m);
    }

    // Heat is higher priority than any water-related state.
    if(in.hot){
        recover=false;waterStage=0;
        if(currentMode!=PlantMode::Heat)return show(now,PlantMode::Heat,Mood::HOT);
        uint32_t elapsed=now-entered;
        if(currentMood==Mood::HOT&&elapsed>=HEAT_FACE_MS)
            return show(now,PlantMode::Heat,Mood::FAN,FAN_MS);
        if(currentMood==Mood::FAN&&elapsed>=FAN_MS)
            return show(now,PlantMode::Heat,Mood::HOT);
        return show(now,PlantMode::Heat,currentMood,duration);
    }
    if(in.soilReady&&isDry(in.soil)){
        recover=false;waterStage=0;
        Mood m=in.soil==SoilState::IntenseThirst?Mood::THIRSTY:Mood::SAD;
        if(in.soil==SoilState::Low)m=Mood::SKEPTICAL;
        return show(now,PlantMode::Dry,m);
    }
    if(in.soilReady&&in.soil==SoilState::Excess){
        recover=false;waterStage=0;
        return show(now,PlantMode::Overwater,Mood::OVERWATERED);
    }

    if(waterQueued&&in.soilReady&&in.soil==SoilState::Adequate){
        waterQueued=false;waterStage=1;waterStageAt=now;inactivityAt=now;recover=false;
    }
    if(waterStage==1){
        if(now-waterStageAt<DRINK_MS)return show(now,PlantMode::Drinking,Mood::DRINKING,DRINK_MS);
        waterStage=2;waterStageAt=now;
    }
    if(waterStage==2){
        if(now-waterStageAt<SATISFIED_MS)return show(now,PlantMode::Satisfied,Mood::SATISFIED,SATISFIED_MS);
        waterStage=0;inactivityAt=now;
    }
    if(recover){
        if(now-recoveryAt<RECOVERY_MS)return show(now,PlantMode::Recovery,Mood::HAPPY);
        recover=false;
    }

    if(now-inactivityAt>=INACTIVITY_MS){
        if(currentMode==PlantMode::Sleeping)return show(now,PlantMode::Sleeping,Mood::SLEEPING);
        if(currentMode!=PlantMode::Yawn)return show(now,PlantMode::Yawn,Mood::TIRED_YAWNING,YAWN_MS);
        if(now-entered>=YAWN_MS)return show(now,PlantMode::Sleeping,Mood::SLEEPING);
        return show(now,PlantMode::Yawn,Mood::TIRED_YAWNING,YAWN_MS);
    }
    if(!initialized||currentMode!=PlantMode::Idle||static_cast<int32_t>(now-nextIdle)>=0){
        uint32_t ms=static_cast<uint32_t>(random(IDLE_MIN,IDLE_MAX+1));
        // Start in NORMAL, then shuffle eligible faces only.
        Mood m=initialized?chooseIdle():Mood::NORMAL;
        nextIdle=now+ms;
        return show(now,PlantMode::Idle,m,ms,true);
    }
    return show(now,PlantMode::Idle,currentMood,duration);
}
