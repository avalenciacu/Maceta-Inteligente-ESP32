#include "PlantSensors.h"
using namespace SystemConfig;

const char* soilName(SoilState state){
    switch(state){
    case SoilState::IntenseThirst: return "SED_INTENSA";
    case SoilState::NeedsWater: return "NECESITA_AGUA";
    case SoilState::Low: return "HUMEDAD_BAJA";
    case SoilState::Adequate: return "ADECUADA";
    case SoilState::Elevated: return "ELEVADA";
    case SoilState::Excess: return "EXCESO";
    }
    return "?";
}
void PlantSensors::begin(uint32_t now){
    soil.begin();
    touch.setFixedThresholds(TOUCH_BASE,TOUCH_PRESS,TOUCH_RELEASE);
    soilStart=now-SOIL_PERIOD;
    tempAt=now-TEMP_PERIOD;
    touchAt=now-TOUCH_PERIOD;
}
void PlantSensors::update(uint32_t now){
    if(now-touchAt>=TOUCH_PERIOD){
        touchAt=now;
        data.touchRaw=touch.read();
        touch.update(data.touchRaw,now);
        data.touching=touch.touched();
    }
    data.touchDuration=touch.duration(now);
    updateSoil(now);
    updateTemp(now);
}
void PlantSensors::updateSoil(uint32_t now){
    if(!soilSampling && now-soilStart>=SOIL_PERIOD){
        soilSampling=true;soilStart=now;sampleAt=now-SOIL_SAMPLE_MS;
        sum=0;n=0;minAdc=4095;maxAdc=0;
    }
    // One conversion per iteration, without the 30 ms delay of the test.
    if(!soilSampling || now-sampleAt<SOIL_SAMPLE_MS)return;
    sampleAt=now;
    uint16_t v=soil.readSample();
    sum+=v;
    if(v<minAdc)minAdc=v;
    if(v>maxAdc)maxAdc=v;
    if(++n>=SOIL_SAMPLES){soilSampling=false;finishSoil(now);}
}
void PlantSensors::finishSoil(uint32_t now){
    data.rawSoil=(sum+SOIL_SAMPLES/2)/SOIL_SAMPLES;
    data.soilRange=maxAdc-minAdc;
    data.filteredAdc=data.soilReady?SOIL_ALPHA*data.rawSoil+(1-SOIL_ALPHA)*data.filteredAdc:data.rawSoil;
    float h=(ADC_DRY-data.filteredAdc)*100.f/(ADC_DRY-ADC_WET);
    data.humidity=h<0?0:(h>100?100:h);
    h=data.humidity;
    if(!data.soilReady){
        int s=0;while(s<5&&h>=SOIL_LIMITS[s])++s;
        data.soil=candidate=static_cast<SoilState>(s);
        data.soilReady=true;candidateAt=now;return;
    }
    int s=static_cast<int>(data.soil);
    while(s<5&&h>=SOIL_LIMITS[s]+SOIL_HYST)++s;
    while(s>0&&h<SOIL_LIMITS[s-1]-SOIL_HYST)--s;
    SoilState next=static_cast<SoilState>(s);
    if(next==data.soil){candidate=data.soil;candidateAt=now;}
    else if(next!=candidate){candidate=next;candidateAt=now;}
    else if(now-candidateAt>=CONFIRM_MS)data.soil=candidate;
}
void PlantSensors::acceptTemperature(float value,uint32_t now){
    data.tempC=value;data.tempValid=true;
    bool next=data.hot?value>HOT_OFF:value>=HOT_ON;
    if(next==data.hot){hotPending=false;return;}
    if(!hotPending||hotCandidate!=next){
        hotPending=true;hotCandidate=next;hotAt=now;return;
    }
    if(now-hotAt>=CONFIRM_MS){data.hot=next;hotPending=false;}
}
void PlantSensors::updateTemp(uint32_t now){
    if(converting&&temp.ready()){
        converting=false;
        float t;
        if(temp.readCelsius(t)){
            // 85 C is the power-up value; reject in this ambient application.
            if(t==85.f){
                data.tempValid=false;hotPending=false;tempConnected=false;
                Serial.println("TEMP: 85 C, revisar alimentacion; reintento");
            }else acceptTemperature(t,now);
        } else {
            data.tempValid=false;hotPending=false;tempConnected=false;
            Serial.println("TEMP: lectura invalida; reintento");
        }
    }
    if(converting||now-tempAt<TEMP_PERIOD)return;
    tempAt=now;
    if(!tempConnected)tempConnected=temp.begin();
    if(!tempConnected){data.tempValid=false;hotPending=false;Serial.println("TEMP: DS18B20 no detectado");return;}
    converting=temp.startConversion();
    if(!converting){tempConnected=false;data.tempValid=false;hotPending=false;}
}
