#include <Arduino.h>
#include <TFT_eSPI.h>
#include <esp_system.h>
#include "MacetaFace.h"
#include "PlantController.h"
#include "SystemConfig.h"

using namespace SystemConfig;
static_assert(static_cast<int>(Mood::COUNT)==52,"El catalogo original debe contener 52 expresiones");
TFT_eSPI tft;
MacetaFace face(tft);
PlantSensors sensors;
PlantController controller;
bool displayReady=false;
uint32_t lastLog=0;
Mood displayed=Mood::NORMAL;

void applyFace(const FaceDecision& d){
    if(!d.changed)return;
    bool freeBrows=d.mode==PlantMode::Idle||d.mode==PlantMode::Recovery;
    face.setRandomBrows(freeBrows);
    if(!freeBrows){
        face.setBrowStyle(d.mode==PlantMode::Stressed||d.mode==PlantMode::Annoyed?BrowStyle::FLAT:BrowStyle::SOFT);
    }
    face.setAutoBlink(true);
    face.setAutoLook(d.mode==PlantMode::Idle);
    face.setAutoGestures(true);
    face.setMood(d.mood,d.duration);
    displayed=d.mood;
    Serial.printf("ESTADO=%s | CARA=%s | DURACION=%lu ms\n",modeName(d.mode),moodName(d.mood),(unsigned long)d.duration);
}

void setup(){
    Serial.begin(SERIAL_BAUD);
    randomSeed(esp_random());
    Serial.println("\nMACETA INTELIGENTE FINAL V1");
    Serial.println("GC9A01 SPI HSPI | HUMEDAD 34 | TEMPERATURA 33 | TOUCH 32");
    tft.init();
    tft.setRotation(0);
    tft.fillScreen(TFT_BLACK);
    displayReady=face.begin();
    if(!displayReady){
        Serial.println("ERROR: memoria del sprite");
        tft.fillScreen(TFT_RED);
    }
    uint32_t now=millis();
    sensors.begin(now);
    controller.begin(now);
    lastLog=now;
}
void loop(){
    uint32_t now=millis();
    sensors.update(now);
    const auto& s=sensors.inputs();
    const FaceDecision d=controller.update(millis(),s);
    if(displayReady){
        applyFace(d);
        face.update();
    }
    now=millis();
    if(now-lastLog>=LOG_MS){
        lastLog=now;
        Serial.printf("ADC=%u | FILTRO=%.1f | HUM=%.2f%% %s | ",
          (unsigned)s.rawSoil,s.filteredAdc,s.humidity,s.soilReady?soilName(s.soil):"INICIALIZANDO");
        if(s.tempValid)Serial.printf("TEMP=%.2f C | ",s.tempC);
        else Serial.print("TEMP=INVALIDA | ");
        Serial.printf("CALOR=%s | TOUCH=%u %s %lu ms | MODO=%s | FPS=%.1f | HEAP=%lu\n",
            s.hot?"SI":"NO",(unsigned)s.touchRaw,s.touching?"TOCADO":"LIBRE",
            (unsigned long)s.touchDuration,modeName(controller.mode()),
            displayReady?face.fps():0.f,(unsigned long)ESP.getFreeHeap());
    }
    yield();
}
