#pragma once
#include "SystemConfig.h"
#include "SoilSensor.h"
#include "TemperatureSensor.h"
#include "TouchSensor.h"

enum class SoilState : uint8_t { IntenseThirst, NeedsWater, Low, Adequate, Elevated, Excess };
inline bool isDry(SoilState s){return s<=SoilState::Low;}
inline bool needsAlert(SoilState s){return isDry(s)||s==SoilState::Excess;}
struct PlantInputs {
    bool soilReady=false, tempValid=false, hot=false, touching=false;
    SoilState soil=SoilState::Adequate;
    float humidity=0.f, tempC=0.f, filteredAdc=0.f;
    uint16_t rawSoil=0, soilRange=0, touchRaw=0;
    uint32_t touchDuration=0;
};
const char* soilName(SoilState state);

class PlantSensors {
public:
    void begin(uint32_t now);
    void update(uint32_t now);
    const PlantInputs& inputs() const { return data; }
private:
    SoilSensor soil{SystemConfig::SOIL_PIN};
    TemperatureSensor temp{SystemConfig::TEMP_PIN};
    TouchSensor touch{SystemConfig::TOUCH_PIN};
    PlantInputs data;
    bool soilSampling=false, tempConnected=false, converting=false;
    uint32_t soilStart=0, sampleAt=0, sum=0, tempAt=0, touchAt=0;
    uint16_t minAdc=4095, maxAdc=0;
    uint8_t n=0;
    SoilState candidate=SoilState::Adequate;
    uint32_t candidateAt=0;
    bool hotCandidate=false;
    uint32_t hotAt=0;
    bool hotPending=false;
    void updateSoil(uint32_t now);
    void finishSoil(uint32_t now);
    void updateTemp(uint32_t now);
    void acceptTemperature(float value,uint32_t now);
};
