#pragma once
#include <Arduino.h>
namespace SystemConfig {
constexpr uint8_t SOIL_PIN=34, TEMP_PIN=33, TOUCH_PIN=32;
constexpr uint32_t SERIAL_BAUD=115200;
constexpr int ADC_DRY=3870, ADC_WET=1419;
constexpr uint8_t SOIL_SAMPLES=16;
constexpr uint32_t SOIL_PERIOD=500, SOIL_SAMPLE_MS=2, CONFIRM_MS=5000;
constexpr float SOIL_ALPHA=0.25f, SOIL_HYST=2.f;
constexpr float SOIL_LIMITS[]={10.f,25.f,32.f,60.f,80.f};
constexpr float HOT_ON=35.f, HOT_OFF=33.f;
constexpr uint32_t TEMP_PERIOD=2000, TOUCH_PERIOD=30;
constexpr float TOUCH_BASE=768.15f, TOUCH_PRESS=288.f, TOUCH_RELEASE=524.f;
constexpr uint32_t INACTIVITY_MS=600000, IDLE_MIN=5000, IDLE_MAX=15000;
constexpr uint32_t TOUCH_ALERT_MS=1000, PET_MS=10000, ANNOYED_MS=15000;
constexpr uint32_t WAKE_MS=3500, YAWN_MS=5000, DRINK_MS=5000, SATISFIED_MS=3000;
constexpr uint32_t HEAT_FACE_MS=6000, FAN_MS=6000, RECOVERY_MS=1200;
constexpr uint32_t TOUCH_DEBOUNCE_MS=80, STRESS_ALTERNATE_MS=5000, WATER_MAX_WAIT=30000;
constexpr uint32_t LOG_MS=1000;
}
