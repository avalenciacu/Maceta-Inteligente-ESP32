#pragma once
#include "PlantSensors.h"
#include "FaceExpressions.h"

enum class PlantMode : uint8_t {
    Idle, Yawn, Sleeping, Waking, TouchAlert, Petting, Annoyed, Stressed,
    Recovery, Heat, Dry, Overwater, Drinking, Satisfied
};
struct FaceDecision {
    Mood mood;
    uint32_t duration;
    PlantMode mode;
    bool changed;
};
const char* modeName(PlantMode mode);

class PlantController {
public:
    void begin(uint32_t now);
    FaceDecision update(uint32_t now,const PlantInputs& in);
    PlantMode mode() const {return currentMode;}
private:
    PlantMode currentMode=PlantMode::Idle;
    Mood currentMood=Mood::NORMAL;
    uint32_t entered=0, inactivityAt=0, duration=0, nextIdle=0;
    bool initialized=false, previousTouch=false, previousNeed=false, knownSoil=false;
    SoilState previousSoil=SoilState::Adequate;
    bool wake=false, alertTouch=false, recover=false, waterQueued=false;
    uint32_t wakeAt=0, touchAlertAt=0, recoveryAt=0, waterAt=0;
    uint8_t waterStage=0;
    uint32_t waterStageAt=0;
    Mood bag[static_cast<unsigned>(Mood::COUNT)];
    uint8_t bagSize=0, bagPos=0;
    Mood recent[4]={Mood::COUNT,Mood::COUNT,Mood::COUNT,Mood::COUNT};
    uint8_t recentPos=0;
    FaceDecision show(uint32_t now,PlantMode mode,Mood mood,uint32_t ms=0,bool force=false);
    Mood chooseIdle();
    bool recentlyShown(Mood m) const;
    void refillBag();
};
