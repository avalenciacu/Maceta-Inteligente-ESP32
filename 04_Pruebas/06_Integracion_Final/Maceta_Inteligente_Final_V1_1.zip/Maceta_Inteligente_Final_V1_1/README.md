# Maceta Inteligente Final V1.1

Proyecto integrado ESP32-WROOM-32 + GC9A01, PlatformIO / Arduino.
Construido a partir de los cuatro proyectos probados de librerias.zip.
Conserva los 52 gráficos originales de MacetaFace V9.1.

## Instalación

1. Descomprimir el ZIP.
2. Abrir la carpeta Maceta_Inteligente_Final_V1_1 (la que contiene platformio.ini)
   en Visual Studio Code con PlatformIO.
3. Build, Upload, Monitor. Monitor serial: 115200 baudios.
   Las bibliotecas externas están incluidas en lib/: TFT_eSPI 2.5.43,
   OneWire 2.3.8 y DallasTemperature 3.11.0, copiadas de librerias.zip.
   No requieren descarga individual; PlatformIO y el entorno ESP32
   Arduino deben estar instalados.
4. No instalar ni copiar manualmente .pio de los proyectos de prueba.

## Conexiones

| Componente | Señal | Conexión |
|---|---|---|
| GC9A01 | VCC y BLK | 3.3 V |
| GC9A01 | GND | GND |
| GC9A01 | SCL | GPIO14 |
| GC9A01 | SDA (MOSI) | GPIO13 |
| GC9A01 | CS | GPIO26 |
| GC9A01 | DC | GPIO27 |
| GC9A01 | RST | GPIO25 |
| FC-28 | A0 | GPIO34 |
| FC-28 | VCC/GND | 3.3 V/GND |
| FC-28 | D0 | Sin conexión |
| DS18B20 | DATA | GPIO33 con pull-up 4.7 kΩ a 3.3 V |
| DS18B20 | VDD/GND | 3.3 V/GND |
| Lámina | Contacto | GPIO32, 1 kΩ en serie |

No conectar la lámina a VCC o GND. Alimentación y tierra común;
no usar 5 V en señales del ESP32. El display conserva HSPI 20 MHz.

## Lógica

- Actividad: selección aleatoria de 33 expresiones elegibles por 5–15 s,
  bolsa barajada y memoria de cuatro expresiones recientes. Las 52
  permanecen disponibles en la biblioteca, no todas se usan al azar.
- Cejas aleatorias 6–15 s durante actividad; se conserva el motor de expresión
  y se fijan cejas durante estados especiales. Parpadeos y miradas naturales.
- A los 10 minutos sin contacto y sin alertas: bostezo de 5 s, luego sueño
  animado (sin suspensión eléctrica; los sensores siguen adquiriendo).
- Toque confirmado: alerta curiosa 1 s, disfrute hasta 10 s, incomodidad
  desde 10 hasta 15 s, estrés desde 15 s. Durante estrés se alterna con enojo
  cada 5 s. Si está dormida: despertar progresivo de 3.5 s, luego alerta
  curiosa de 1 s y reacción de acuerdo con duración real del contacto.
  Un toque corto conserva la reacción breve. Al soltar, vuelve a una alerta
  vigente; sin alerta vuelve a actividad. El contacto reinicia la inactividad.
- Necesidades ambientales impiden dormir. Al resolverse una alerta se
  reinicia el plazo de actividad de 10 min.
- Prioridad visual: secuencia táctil temporal > calor > falta/exceso de agua
  > evento de riego > descanso/actividad. El calor alterna HOT y FAN cada 6 s.
- Temperatura: activa calor >= 35 °C, se libera <= 33 °C;
  confirmación 5 s de lecturas válidas. No hay alerta de frío.
  Una lectura inválida no genera calor nuevo; se conserva la última alerta
  confirmada hasta recibir datos válidos que permitan cambiarla.
- Riego: DRINKING 5 s + SATISFIED 3 s solo tras transición confirmada desde
  una de las tres categorías secas a ADEQUATE. No se activa al arrancar, ni
  al pasar directamente al exceso. Si hay calor/contacto, el evento queda
  pendiente hasta 30 s y se cancela si cambia la humedad. Si un toque
  interrumpe una animación de riego ya iniciada, no se repite. Si aparece
  exceso, muestra OVERWATERED, sin satisfacción.
- Humedad elevada (60–80 %) no activa una alerta por sí sola.
  Humedad baja muestra SKEPTICAL, necesita agua SAD, sed intensa THIRSTY.
- La pantalla mantiene BLK fijo; no se implementa deep sleep ni riego
  automático, sonido o conexión a Internet.

## Configuración ajustable

Todas las constantes principales están en include/SystemConfig.h.
- Humedad: ADC seco 3870, saturado 1419. Promedio 16 lecturas, nueva tanda
  cada 500 ms si el tiempo de ejecución lo permite; EMA 0.25. Clasificación
  10/25/32/60/80 %, histéresis ±2 puntos, confirmación 5 s. El valor es un
  índice relativo, no un porcentaje absoluto de contenido de agua.
- Touch: base registrada 768.15; toque <=288, soltar >=524, confirmación
  80 ms. Umbrales fijos; no se necesita calibración serial al arrancar.
- DS18B20: 12 bits, conversión no bloqueante con espera de 800 ms,
  nuevo intento cada 2 s aproximadamente. Detecta fallo y reintenta.
  85 °C se trata como dato sospechoso de reinicio en este montaje ambiental.
- La frecuencia de muestreo efectiva depende del renderizado y del hardware.
  El diagnóstico informa FPS y memoria libre; no promete 40 FPS.

## Archivos

include/ y src/: motor gráfico original (Face*, MacetaFace);
drivers originales con pequeñas extensiones (SoilSensor, TouchSensor);
TemperatureSensor (driver no bloqueante de la prueba original);
PlantSensors (adquisición/clasificación), PlantController (máquina de estados),
SystemConfig (constantes), main.cpp (orquestación).
CATALOGO.txt conserva las 52 expresiones originales.
PRUEBAS.md describe qué comprobar físicamente.
qa_host/ contiene comprobaciones simuladas con sustitutos mínimos del entorno.

## Verificación

La sintaxis de los módulos nuevos, drivers y main.cpp se comprobó en C++11
con sustitutos de Arduino/OneWire/DallasTemperature/TFT_eSPI. La prueba
simulada verifica prioridad, eventos, temporizadores e histéresis.
Los archivos gráficos originales no se modificaron. No se ejecutó una
compilación completa de PlatformIO ni una prueba física integrada en este
entorno. La prueba final corresponde al ESP32 del usuario.
