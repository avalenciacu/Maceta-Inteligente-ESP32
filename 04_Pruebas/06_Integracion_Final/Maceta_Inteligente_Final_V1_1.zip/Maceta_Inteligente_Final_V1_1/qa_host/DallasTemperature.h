#pragma once
#include <OneWire.h>
typedef uint8_t DeviceAddress[8];
#define DEVICE_DISCONNECTED_C -127
class DallasTemperature {
public:
 explicit DallasTemperature(OneWire*){}
 void begin(){}
 bool getAddress(uint8_t* a,uint8_t){a[0]=0x28;return simulatedPresent;}
 bool setResolution(const uint8_t*,uint8_t){return simulatedPresent;}
 void setWaitForConversion(bool){}
 struct request_t { bool result; unsigned long timestamp; operator bool(){return result;} };
 request_t requestTemperaturesByAddress(const uint8_t*){return {simulatedPresent,millis()};}
 float getTempC(const uint8_t*){return simulatedPresent?simulatedTemp:-127.f;}
};
