#pragma once
#include <stdint.h>
#include <stdlib.h>
#define INPUT 0
#define ADC_11db 3
extern uint32_t simulatedMillis;
extern uint16_t simulatedTouch,simulatedAdc;
extern float simulatedTemp;
extern bool simulatedPresent;
inline uint32_t millis(){return simulatedMillis;}
inline void delay(unsigned long n){simulatedMillis+=n;}
inline void yield(){}
inline long random(long max){return rand()%max;}
inline long random(long min,long max){return min+random(max-min);}
inline void randomSeed(unsigned long seed){srand(seed);}
inline void pinMode(uint8_t,int){}
inline void analogReadResolution(int){}
inline void analogSetPinAttenuation(uint8_t,int){}
inline int analogRead(uint8_t){return simulatedAdc;}
inline uint16_t touchRead(uint8_t){return simulatedTouch;}
struct SerialType {
 void begin(unsigned long){}
 void println(const char* = ""){}
 void print(const char*){}
 template<class... Args> void printf(const char*,Args...){}
};
extern SerialType Serial;
struct EspType{unsigned long getFreeHeap(){return 100000;}};
extern EspType ESP;
