#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
bin="$(mktemp)"
trap 'rm -f "$bin"' EXIT
g++ -std=c++11 -Wall -Wextra -Werror -Iqa_host -Iinclude -fsyntax-only src/main.cpp src/PlantController.cpp src/PlantSensors.cpp src/SoilSensor.cpp src/TouchSensor.cpp src/TemperatureSensor.cpp
g++ -std=c++11 -Wall -Wextra -Werror -Iqa_host -Iinclude qa_host/test.cpp src/PlantController.cpp src/PlantSensors.cpp src/SoilSensor.cpp src/TouchSensor.cpp src/TemperatureSensor.cpp -o "$bin"
"$bin"
