#pragma once
#include <Arduino.h>
#define TFT_BLACK 0
#define TFT_RED 0xf800
class TFT_eSPI { public: void init(){} void setRotation(int){} void fillScreen(uint16_t){} };
class TFT_eSprite { public: explicit TFT_eSprite(TFT_eSPI*){} };
