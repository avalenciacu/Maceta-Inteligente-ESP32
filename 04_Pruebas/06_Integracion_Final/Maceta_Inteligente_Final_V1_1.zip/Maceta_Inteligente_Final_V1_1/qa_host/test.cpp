#include "PlantController.h"
#include <cassert>
#include <cstdio>
uint32_t simulatedMillis=0;
uint16_t simulatedTouch=768,simulatedAdc=2969;
float simulatedTemp=24;
bool simulatedPresent=true;
SerialType Serial; EspType ESP;
using namespace SystemConfig;
static void expect(PlantController& c,uint32_t t,const PlantInputs& in,PlantMode mode,Mood mood){
    auto d=c.update(t,in);assert(d.mode==mode);assert(d.mood==mood);
}
int main(){
    PlantController c;PlantInputs in;in.soilReady=true;in.tempValid=true;
    c.begin(0);
    expect(c,0,in,PlantMode::Idle,Mood::NORMAL);
    auto d=c.update(100,in);assert(!d.changed);
    // Allowed idle collection and durations; never need-related moods.
    for(uint32_t t=15000;t<600000;t+=15000){
        d=c.update(t,in);assert(d.mode==PlantMode::Idle);
        assert(d.duration>=IDLE_MIN&&d.duration<=IDLE_MAX);
        assert(d.mood!=Mood::SAD&&d.mood!=Mood::HOT&&d.mood!=Mood::COLD&&d.mood!=Mood::ANGRY&&d.mood!=Mood::STRESSED&&d.mood!=Mood::DRINKING);
    }
    expect(c,600000,in,PlantMode::Yawn,Mood::TIRED_YAWNING);
    expect(c,605000,in,PlantMode::Sleeping,Mood::SLEEPING);
    in.touching=true;in.touchDuration=0;
    expect(c,606000,in,PlantMode::Waking,Mood::WAKE_UP);
    in.touchDuration=3500;expect(c,609500,in,PlantMode::TouchAlert,Mood::TOUCH_ALERT);
    in.touchDuration=4500;expect(c,610500,in,PlantMode::Petting,Mood::PETTED);
    in.touchDuration=10000;expect(c,616000,in,PlantMode::Annoyed,Mood::ANNOYED);
    in.touchDuration=15000;expect(c,621000,in,PlantMode::Stressed,Mood::STRESSED);
    in.touchDuration=20000;expect(c,626000,in,PlantMode::Stressed,Mood::ANGRY);
    in.touching=false;in.hot=true;in.soil=SoilState::NeedsWater;
    expect(c,626050,in,PlantMode::Heat,Mood::HOT);
    expect(c,632050,in,PlantMode::Heat,Mood::FAN);
    in.hot=false;expect(c,633000,in,PlantMode::Dry,Mood::SAD);
    in.touching=true;in.touchDuration=0;expect(c,634000,in,PlantMode::TouchAlert,Mood::TOUCH_ALERT);
    in.touchDuration=1000;expect(c,635000,in,PlantMode::Petting,Mood::PETTED);
    in.touching=false;expect(c,635100,in,PlantMode::Dry,Mood::SAD);
    in.soil=SoilState::Adequate;expect(c,636000,in,PlantMode::Drinking,Mood::DRINKING);
    expect(c,641000,in,PlantMode::Satisfied,Mood::SATISFIED);
    assert(c.update(644000,in).mode==PlantMode::Idle);
    in.soil=SoilState::Excess;expect(c,645000,in,PlantMode::Overwater,Mood::OVERWATERED);
    in.soil=SoilState::Adequate;assert(c.update(646000,in).mode==PlantMode::Idle);
    in.soil=SoilState::IntenseThirst;expect(c,647000,in,PlantMode::Dry,Mood::THIRSTY);
    in.soil=SoilState::Excess;expect(c,648000,in,PlantMode::Overwater,Mood::OVERWATERED);
    // Check timer rollover.
    PlantController rollover;PlantInputs normal;normal.soilReady=true;rollover.begin(0xfffffff0u);
    rollover.update(0xfffffff0u,normal);
    expect(rollover,0xfffffff0u+INACTIVITY_MS,normal,PlantMode::Yawn,Mood::TIRED_YAWNING);
    // Sensor pipeline with fake measurements.
    PlantSensors sensors;sensors.begin(0);
    auto until=[&](uint32_t end){for(;simulatedMillis<=end;simulatedMillis+=2)sensors.update(simulatedMillis);};
    until(3000);assert(sensors.inputs().soil==SoilState::Adequate);assert(sensors.inputs().tempValid);
    simulatedTemp=36;until(12000);assert(sensors.inputs().hot);
    simulatedTemp=34;until(20000);assert(sensors.inputs().hot);
    simulatedTemp=32;until(30000);assert(!sensors.inputs().hot);
    simulatedAdc=3870;until(48000);assert(sensors.inputs().soil==SoilState::IntenseThirst);
    simulatedTouch=50;until(49000);assert(sensors.inputs().touching);
    simulatedTouch=400;until(49500);assert(sensors.inputs().touching);
    simulatedTouch=768;until(50000);assert(!sensors.inputs().touching);
    simulatedAdc=2969;until(68000);assert(sensors.inputs().soil==SoilState::Adequate);
    simulatedPresent=false;until(72000);assert(!sensors.inputs().tempValid);
    simulatedPresent=true;until(76000);assert(sensors.inputs().tempValid);
    puts("OK: controller and sensor simulation");
}
