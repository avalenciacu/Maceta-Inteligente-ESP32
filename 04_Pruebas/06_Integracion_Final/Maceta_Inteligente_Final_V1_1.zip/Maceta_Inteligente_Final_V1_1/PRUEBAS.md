# Lista de comprobación de prueba integrada

1. Arranque: la pantalla muestra una cara, se registran los tres sensores
   en el monitor serial (115200). Verificar TEMP válida, ADC/HUM y TOUCH.
   Si aparece TEMP INVALIDA, comprobar 3.3 V, GPIO33, GND y pull-up.
2. Humedad suficiente y temperatura normal: actividades espontáneas cada
   5–15 s, sin expresiones de calor, sed, tristeza, estrés ni exceso.
3. Toque breve, toque sostenido 2 s, 10 s, 15 s y más de 20 s:
   alerta curiosa, disfrute, incomodidad, estrés/enojo. Soltar.
4. Tierra seca: tras filtro/confirmación, mostrar necesidad. Tocar y
   comprobar disfrute temporal y retorno a necesidad al soltar.
5. Riego: subir desde una categoría seca hasta adecuada (<60 %, según la
   clasificación con histéresis). Esperar confirmación. Una sola secuencia
   de beber y satisfacción. No debe dispararse al arrancar en húmedo.
6. Exceso: usar una muestra separada de tierra saturada, no inundar la
   planta. Verificar OVERWATERED después de confirmación.
7. Calor: acercar agua tibia en recipiente cerrado, no llama directa.
   Mantener >=35 °C, verificar HOT/FAN y prioridad sobre falta de agua.
   Cuando <=33 °C de forma confirmada, volver a la necesidad restante.
8. Descanso: sin tocar y sin alertas, esperar 10 min, observar bostezo y
   sueño animado. Verificar que los datos seriales siguen cambiando.
   Tocar: despertar, mirar alrededor y disfrutar si continúa.
   Repetir con necesidad ambiental durante el sueño.
9. Desconectar y reconectar el DS18B20 con alimentación apagada si se
   cambia cableado. Verificar diagnóstico sin alerta espuria.
10. Registrar el FPS, HEAP, tiempos de respuesta y comportamiento con
    el montaje de la lámina definitivo y todos los componentes activos.

Para pruebas rápidas puede reducirse INACTIVITY_MS temporalmente en
SystemConfig.h; restaurar 600000 antes de la demostración.

NOTA: filtros, intervalos de lectura y confirmación introducen latencia.
No interpretar un cambio físico instantáneo como fallo de software.
